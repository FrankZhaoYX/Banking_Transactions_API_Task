package com.bank.frank_BrainRidge_interview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrankBrainRidgeInterviewApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.bank.frank_BrainRidge_interview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrankBrainRidgeInterviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrankBrainRidgeInterviewApplication.class, args);
	}

}
